package edu.cpst343.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_add:
                //TODO: Add new profile selected
                return true;

            case R.id.action_about:
                //TODO: About selected
                return true;

            case R.id.action_user_info:
                //TODO: User Info selected
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void onTipsTricksClicked(View view) {
        Intent intent = new Intent(this, ListActivity.class);
        startActivity(intent);
    }

}

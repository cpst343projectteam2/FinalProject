package edu.cpst343.finalproject;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class ListActivity extends AppCompatActivity implements ListFragment.OnTopicSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.list_fragment_container);

        if (fragment == null) {
            fragment = new ListFragment();
            fragmentManager.beginTransaction()
                    .add(R.id.list_fragment_container, fragment)
                    .commit();
        }
    }

    @Override
    public void onTopicSelected(int topicId) {
        // Send the topic ID of the clicked button to DetailsActivity
        Intent intent = new Intent(this, DetailsActivity.class);
        intent.putExtra(DetailsActivity.EXTRA_TOPIC_ID, topicId);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_select_profile:
                //TODO: Profile selection
                return true;
            case R.id.action_home:
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                return true;

                case R.id.action_profiles:
                //TODO: Puppy Profiles selected
                return true;

            case R.id.action_daily_trackers:
                //TODO: Daily Trackers selected
                return true;

            case R.id.action_user_info:
                //TODO: User Info selected
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
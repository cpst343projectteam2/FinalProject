package edu.cpst343.finalproject;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class DetailsFragment extends Fragment {

    private Topic mTopic;

    public static DetailsFragment newInstance(int topicId) {
        DetailsFragment fragment = new DetailsFragment();
        Bundle args = new Bundle();
        args.putInt("topicId", topicId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get the topic ID from the intent that started DetailsActivity
        int topicId = 1;
        if (getArguments() != null) {
            topicId = getArguments().getInt("topicId");
        }

        mTopic = TopicDatabase.getInstance(getContext()).getTopic(topicId);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_details, container, false);

        TextView nameTextView = view.findViewById(R.id.topicName);
        nameTextView.setText(mTopic.getName());

        TextView descriptionTextView = view.findViewById(R.id.topicInformation);
        descriptionTextView.setMovementMethod(new ScrollingMovementMethod());
        descriptionTextView.setText(mTopic.getInformation());


        return view;
    }
}

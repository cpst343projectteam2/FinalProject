package edu.cpst343.finalproject;

import android.text.Html;
import android.text.Spanned;

import static android.text.Html.FROM_HTML_MODE_LEGACY;

public class Topic {
    private int mId;
    private String mName;
    private String[] mInformationArray;
    private Spanned mInformation;

    public Topic() {}

    public Topic(int id, String name, String[] information) {
        mId = id;
        mName = name;
        mInformationArray = information;
        mInformation = null;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        this.mId = id;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public String[] getInformationArray(){
        return mInformationArray;
    }

    public Spanned getInformation() {
        return mInformation;
    }

    public void setInformation(String information) {
        Spanned styledText = Html.fromHtml(information, FROM_HTML_MODE_LEGACY);
        this.mInformation = styledText;
    }
}

package edu.cpst343.finalproject;

import android.content.Context;
import android.content.res.Resources;

import java.util.ArrayList;
import java.util.List;

public class TopicDatabase {

    private static int dogAge;
    private static int dogSize;
    //TODO: get dogAge and dogSize from Profile Activity
    private static String[] feedingAmounts;
    private static String[] feedingFrequency;
    private static String[] training;
    private static String[] preventativeCare;
    private static String[] developmentStage;

    private static TopicDatabase sTopicDatabase;
    private List<Topic> mTopics;

    public static TopicDatabase getInstance(Context context) {
        if (sTopicDatabase == null) {
            sTopicDatabase = new TopicDatabase(context);
        }
        return sTopicDatabase;
    }

    private TopicDatabase(Context context) {
        mTopics = new ArrayList<>();
        Resources res = context.getResources();

        String[] topics = res.getStringArray(R.array.topics);
        feedingAmounts = res.getStringArray(R.array.feeding_amount);
        feedingFrequency = res.getStringArray(R.array.feeding_frequency);
        training = res.getStringArray(R.array.training);
        preventativeCare = res.getStringArray(R.array.preventative_care);
        developmentStage = res.getStringArray(R.array.development_stage);

        mTopics.add(new Topic(1, topics[0], feedingFrequency));
        mTopics.add(new Topic(2, topics[1], training));
        mTopics.add(new Topic(3, topics[2], preventativeCare));
        mTopics.add(new Topic(4, topics[3], developmentStage));

        dogAge = 18;
        dogSize = 50;
        //TODO: Remove after getting dogAge and dogSize from Profile Activity
        setDetails();
    }

    private String setFoodAmount() {
        String feedingAmount = null;

        if ( (dogAge >= 4) && (dogAge <= 12) ) {

            if (dogSize <= 20) {
                feedingAmount = feedingAmounts[0];

            }

            else if (dogSize <= 50) {
                feedingAmount = feedingAmounts[1];
            }

            else if (dogSize <= 100) {
                feedingAmount = feedingAmounts[2];
            }

            else if (dogSize > 100) {
                feedingAmount = feedingAmounts[3];
            }
        }

        else if (dogAge <= 20) {

            if (dogSize <= 20) {
                feedingAmount = feedingAmounts[4];
            }

            else if (dogSize <= 50) {
                feedingAmount = feedingAmounts[5];
            }

            else if (dogSize <= 100) {
                feedingAmount = feedingAmounts[6];
            }

            else if (dogSize > 100) {
                feedingAmount = feedingAmounts[7];
            }
        }

        else if (dogAge <= 24) {

            if (dogSize <= 20) {
                feedingAmount = feedingAmounts[8];
            }

            else if (dogSize <= 50) {
                feedingAmount = feedingAmounts[9];
            }

            else if (dogSize <= 100) {
                feedingAmount = feedingAmounts[10];
            }

            else if (dogSize > 100) {
                feedingAmount = feedingAmounts[11];
            }
        }

        else if (dogAge <= 48) {

            if (dogSize <= 20) {
                feedingAmount = feedingAmounts[12];
            }

            else if (dogSize <= 50) {
                feedingAmount = feedingAmounts[13];
            }

            else if (dogSize <= 100) {
                feedingAmount = feedingAmounts[14];
            }

            else if (dogSize > 100) {
                feedingAmount = feedingAmounts[15];
            }
        }

        return feedingAmount;
        //TODO: Use fraction characters in strings.xml
    }

    private void setDetails() {
        Topic feedingTopic = getTopic(1);
        Topic trainingTopic = getTopic(2);
        Topic preventativeCareTopic = getTopic(3);
        Topic developmentStageTopic = getTopic(4);
        String feedingDetail = null;
        String trainingDetail = null;
        String preventativeCareDetail = null;
        String developmentStageDetail = null;

        switch (dogAge) {
            case 0:
            case 1:
            case 2:
                developmentStageDetail = developmentStage[0];
                preventativeCareDetail = preventativeCare[0];
                trainingDetail = training[0];
                feedingDetail = feedingFrequency[0];
                break;
            case 3:
                developmentStageDetail = developmentStage[1];
                preventativeCareDetail = preventativeCare[0];
                trainingDetail = training[0];
                feedingDetail = feedingFrequency[0];
                break;
            case 4:
            case 5:
            case 6:
                developmentStageDetail = developmentStage[2];
                preventativeCareDetail = preventativeCare[0];
                trainingDetail = training[1];
                feedingDetail = feedingFrequency[1];
                break;
            case 7:
            case 8:
                developmentStageDetail = developmentStage[2];
                preventativeCareDetail = preventativeCare[0];
                trainingDetail = training[2];
                feedingDetail = feedingFrequency[2];
                break;
            case 9:
            case 10:
            case 11:
            case 12:
                developmentStageDetail = developmentStage[2];
                preventativeCareDetail = preventativeCare[1];
                trainingDetail = training[3];
                feedingDetail = feedingFrequency[2];
                break;
            case 13:
            case 14:
                developmentStageDetail = developmentStage[3];
                preventativeCareDetail = preventativeCare[2];
                trainingDetail = training[4];
                feedingDetail = feedingFrequency[3];
                break;
            case 15:
            case 16:
            case 17:
                developmentStageDetail = developmentStage[3];
                preventativeCareDetail = preventativeCare[3];
                trainingDetail = training[5];
                feedingDetail = feedingFrequency[3];
                break;
            case 18:
            case 19:
            case 20:
                developmentStageDetail = developmentStage[3];
                preventativeCareDetail = preventativeCare[4];
                trainingDetail = training[6];
                feedingDetail = feedingFrequency[3];
                break;
            case 21:
            case 22:
            case 23:
            case 24:
                developmentStageDetail = developmentStage[3];
                preventativeCareDetail = preventativeCare[5];
                trainingDetail = training[7];
                feedingDetail = feedingFrequency[3];
                break;
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
            case 40:
            case 41:
            case 42:
            case 43:
            case 44:
            case 45:
            case 46:
            case 47:
            case 48:
                developmentStageDetail = developmentStage[4];
                preventativeCareDetail = preventativeCare[6];
                trainingDetail = training[8];
                feedingDetail = feedingFrequency[4];
                break;
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 58:
            case 59:
            case 60:
            case 61:
            case 62:
            case 63:
            case 64:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 71:
            case 72:
                developmentStageDetail = developmentStage[4];
                preventativeCareDetail = preventativeCare[7];
                trainingDetail = training[9];
                feedingDetail = feedingFrequency[5];
                break;
            default:
                developmentStageDetail = "Congratulations, your puppy has grown into an adult dog!";
                preventativeCareDetail = "Congratulations, your puppy has grown into an adult dog!";
                trainingDetail = "Congratulations, your puppy has grown into an adult dog!";
                feedingDetail = "Congratulations, your puppy has grown into an adult dog!";
                //TODO: Update default response
        }

        String amount = setFoodAmount();
        String feedingDetailComplete = feedingDetail + amount;

        feedingTopic.setInformation(feedingDetailComplete);
        trainingTopic.setInformation(trainingDetail);
        preventativeCareTopic.setInformation(preventativeCareDetail);
        developmentStageTopic.setInformation(developmentStageDetail);
    }

    public List<Topic> getTopics() {
        return mTopics;
    }

    public Topic getTopic(int topicId) {
        for (Topic topic : mTopics) {
            if (topic.getId() == topicId) {
                return topic;
            }
        }
        return null;
    }

}